<?php

namespace BanchileChile\PaymentMethod\Constants;

use BanchileChile\PaymentMethod\Countries\BelizeCountryConfig;
use BanchileChile\PaymentMethod\Countries\ChileCountryConfig;
use BanchileChile\PaymentMethod\Countries\ColombiaCountryConfig;
use BanchileChile\PaymentMethod\Countries\EcuadorCountryConfig;
use BanchileChile\PaymentMethod\Countries\HondurasCountryConfig;
use BanchileChile\PaymentMethod\Countries\UruguayCountryConfig;
use BanchileChile\PaymentMethod\CountryConfig;

interface Country
{
    const EC = 'EC';
    const UY = 'UY';
}
