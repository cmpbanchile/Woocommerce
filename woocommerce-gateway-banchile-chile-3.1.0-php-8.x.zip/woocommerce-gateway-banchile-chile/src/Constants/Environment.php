<?php

namespace BanchileChile\PaymentMethod\Constants;

/**
 * Interface Environment
 * @package PlacetoPay\GatewayMethodBanchileChile\Constants
 */
interface Environment
{
    const PROD = 'prod';

    const DEV = 'dev';

    const TEST = 'test';

    const CUSTOM = 'custom';
}