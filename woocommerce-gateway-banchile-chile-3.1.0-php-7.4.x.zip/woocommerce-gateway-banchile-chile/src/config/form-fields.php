<?php

use BanchileChile\PaymentMethod\Constants\Country;
use BanchileChile\PaymentMethod\CountryConfig;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * @var \BanchileChile\PaymentMethod\GatewayMethodBanchileChile $this
 */

return CountryConfig::getFields($this);

