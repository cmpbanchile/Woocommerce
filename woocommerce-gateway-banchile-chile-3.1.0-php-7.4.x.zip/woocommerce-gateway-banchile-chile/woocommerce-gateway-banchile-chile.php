<?php
/**
 * Plugin Name: WooCommerce Banchile Pagos Gateway
 * Plugin URI: https://docs-gateway.placetopay.com/docs/webcheckout-docs/9016e976d1ea0-plugins-y-componentes
 * Description: Adds Banchile Pagos Payment Gateway to WooCommerce e-commerce plugin
 * Author: Banchile Pagos
 * Author URI: https://www.evertecinc.com/pasarela-de-pagos-e-commerce/
 * Developer: Banchile Pagos
 * Version: 3.1.0
 *
 * @package PlacetoPay/WC_Gateway_PlacetoPay
 *
 * @author Soporte <soporte@placetopay.com>
 * @copyright (c) 2013-2024 Evertec PlacetoPay S.A.S.
 * @version 3.1.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if ( is_admin() ) {
    add_filter( 'all_plugins', 'dynamic_plugin_name_banchile_chile' );
}

/**
 * @param array $plugins
 * @return array
 */
if ( ! function_exists( 'dynamic_plugin_name_banchile_chile' ) ) {
function dynamic_plugin_name_banchile_chile( $plugins ) {
    $plugin_file = plugin_basename( __FILE__ );
    if ( isset( $plugins[ $plugin_file ] ) ) {
        $settings = get_option( 'woocommerce_banchile_chile_settings', false );
        $client = \BanchileChile\PaymentMethod\CountryConfig::CLIENT;
        $plugins[ $plugin_file ]['Name'] = 'WooCommerce '. $client . ' Gateway';
        $plugins[ $plugin_file ]['Description'] = 'Adds ' . $client  . ' Payment Gateway to WooCommerce e-commerce plugin';
        $plugins[ $plugin_file ]['Author'] = $client;
    }
    return $plugins;
}
}

/**
 * @return \BanchileChile\PaymentMethod\WC_Gateway_BanchileChile
 */
/**
 * Cargar traducciones del plugin
 * IMPORTANTE: WordPress 6.7+ requiere que se cargue en 'init' o después
 */
if ( ! function_exists( 'load_banchile_chile_textdomain' ) ) {
function load_banchile_chile_textdomain() {
    load_plugin_textdomain('woocommerce-gateway-translations', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
}
add_action('init', 'load_banchile_chile_textdomain', 1);

/**
 * @return \BanchileChile\PaymentMethod\WC_Gateway_BanchileChile
 */
function wc_gateway_banchile_chile()
{
    add_filter('woocommerce_locate_template', 'wooAddonPluginTemplate_banchile_chile', 201, 3);

    /**
     * @param $template
     * @param $templateName
     * @param $templatePath
     * @return string
     */
    if ( ! function_exists( 'wooAddonPluginTemplate_banchile_chile' ) ) {
    function wooAddonPluginTemplate_banchile_chile($template, $templateName, $templatePath)
    {
        global $woocommerce;

        $_template = $template;

        if (!$templatePath) {
            $templatePath = $woocommerce->template_url;
        }

        $pluginPath = untrailingslashit(plugin_dir_path(__FILE__)) . '/woocommerce/';

        $template = locate_template([
            $templatePath . $templateName,
            $templateName
        ]);

        if (!$template && file_exists($pluginPath . $templateName)) {
            $template = $pluginPath . $templateName;
        }

        if (!$template) {
            $template = $_template;
        }

        return $template;
    }
    }

    require_once(__DIR__ . '/src/helpers.php');

    // Cargar el autoloader de Composer solo si no está ya cargado
    // Esto evita conflictos cuando múltiples plugins de la misma familia están instalados
    $autoload_file = __DIR__ . '/vendor/autoload.php';
    if (file_exists($autoload_file)) {
        // Verificar si el autoloader ya fue incluido por otro plugin
        // Cada plugin tiene su propio vendor/autoload.php con hash único
        require_once($autoload_file);
    }

    // Incluir directamente el archivo de la clase principal para asegurar que se carga
    // El autoloader puede no encontrarlo si el namespace cambió
    require_once(__DIR__ . '/src/WC_Gateway_BanchileChile.php');

    return \BanchileChile\PaymentMethod\WC_Gateway_BanchileChile::getInstance(
        \BanchileChile\PaymentMethod\GatewayMethodBanchileChile::VERSION,
        __FILE__
    );
}

add_action('plugins_loaded', 'wc_gateway_banchile_chile', 0);
